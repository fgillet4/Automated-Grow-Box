# Automated-Grow-Box
This repository features arduino code and python code for plotting grow box data in real time and also responding to disturbances in set point value.
